#include <assert.h>
#include "merge_sort.h"

void merge_sort(uint32_t *arr, unsigned start, unsigned end, uint32_t *temp) {
  assert(end >= start);

  unsigned num_elements = end - start;

  if (num_elements < 2) {
    // a sequence of length 0 or 1 is trivially already sorted
    return;
  }

  // Split region to sort into two halves, and recursively
  // sort the halves
  unsigned mid = (start + end) / 2;
  merge_sort(arr, start, mid, temp);
  merge_sort(arr, mid, end, temp);

  // Merge the sorted halves so that the entire region is sorted
  merge(arr, start, mid, end, temp);
}


