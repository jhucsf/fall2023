#include <stdlib.h>
#include <string.h>
#include "tctest.h"
#include "merge_sort.h"

const uint32_t small_unsorted_init[] = {
  34, 55, 7, 27, 95, 94, 69, 54, 83, 72
};

const uint32_t med_unsorted_init[] = {
  93, 45, 94, 14, 11, 83, 52, 5, 49, 89,
  6, 20, 0, 39, 90, 30, 48, 78, 50, 19,
  60, 15, 9, 99, 8, 97, 62, 17, 71, 7
};

const uint32_t small_merge_init[] = {
  7, 27, 34, 55, 95,  // left side
  54, 69, 72, 83, 94, // right side
};

const uint32_t med_merge_init[] = {
  0, 5, 6, 11, 14, 20, 39, 45, 49, 52, 83, 89, 90, 93, 94, // left side
  7, 8, 9, 15, 17, 19, 30, 48, 50, 60, 62, 71, 78, 97, 99, // right side
};

const uint32_t small_sorted[] = {
  7, 27, 34, 54, 55, 69, 72, 83, 94, 95,
};

const uint32_t med_sorted[] = {
  0, 5, 6, 7, 8, 9, 11, 14, 15, 17, 19, 20, 30, 39, 45,
  48, 49, 50, 52, 60, 62, 71, 78, 83, 89, 90, 93, 94, 97, 99,
};

typedef struct {
  uint32_t small_unsorted[10];
  uint32_t med_unsorted[30];

  uint32_t small_merge[10];
  uint32_t med_merge[30];

  // temp array, large enough for all tests
  uint32_t temp[30];
} TestObjs;

// create and destroy test fixture
TestObjs *setup(void);
void cleanup(TestObjs *objs);

// test functions
void test_merge_small(TestObjs *objs);
void test_merge_med(TestObjs *objs);
void test_sort_small(TestObjs *objs);
void test_sort_med(TestObjs *objs);

int main(int argc, char *argv[]) {
  if (argc > 1) {
    tctest_testname_to_execute = argv[1];
  }

  TEST_INIT();

  TEST(test_merge_small);
  TEST(test_merge_med);
  TEST(test_sort_small);
  TEST(test_sort_med);

  TEST_FINI();
}

TestObjs *setup(void) {
  TestObjs *objs = malloc(sizeof(TestObjs));
  memcpy(objs->small_unsorted, small_unsorted_init, sizeof(objs->small_unsorted));
  memcpy(objs->med_unsorted, med_unsorted_init, sizeof(objs->med_unsorted));
  memcpy(objs->small_merge, small_merge_init, sizeof(objs->small_merge));
  memcpy(objs->med_merge, med_merge_init, sizeof(objs->med_merge));
  return objs;
}

void cleanup(TestObjs *objs) {
  free(objs);
}

// Check array to make sure it is completely sorted
#define CHECK_ARRAY(arr, oracle, num_elements) \
do { \
  for (unsigned i = 0; i < num_elements; i++) { \
    ASSERT(arr[i] == oracle[i]); \
  } \
} while (0)

void test_merge_small(TestObjs *objs) {
  merge(objs->small_merge, 0, 5, 10, objs->temp);

  // array should now be sorted
  CHECK_ARRAY(objs->small_merge, small_sorted, 10);
}

void test_merge_med(TestObjs *objs) {
  merge(objs->med_merge, 0, 15, 30, objs->temp);

  // array should now be sorted
  CHECK_ARRAY(objs->med_merge, med_sorted, 30);
}

void test_sort_small(TestObjs *objs) {
  merge_sort(objs->small_unsorted, 0, 10, objs->temp);

  // array should now be sorted
  CHECK_ARRAY(objs->small_unsorted, small_sorted, 10);
}

void test_sort_med(TestObjs *objs) {
  merge_sort(objs->med_unsorted, 0, 30, objs->temp);

  // array should now be sorted
  CHECK_ARRAY(objs->med_unsorted, med_sorted, 30);
}
