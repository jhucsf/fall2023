#! /usr/bin/env ruby

raise "Usage: gen_sorted.rb <array name> [<nitems> [<max val>]]" if ARGV.length == 0

$arr_name = ARGV[0]

$nitems = 10
$max = 100000

if ARGV.length > 1
  $nitems = ARGV[1].to_i
  if ARGV.length > 2
    $max = ARGV[2].to_i
  end
end

data = []
$nitems.times do
  data.push(rand($max))
end
data.sort!

puts "\t#{$arr_name} = (uint32_t *) malloc(sizeof(uint32_t) * #{$nitems});"

ct = 0
data.each do |value|
  puts "\t#{$arr_name}[#{ct}] = #{value};"
  ct += 1
end
