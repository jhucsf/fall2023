#include <stdlib.h>
#include <stdint.h>
#include "tctest.h"

// C prototype for the function we're testing
void merge(const uint32_t *arr1, uint32_t len1, const uint32_t *arr2, uint32_t len2, uint32_t *result_arr);

// test array data
typedef struct {
	uint32_t *a1;
	uint32_t *a2;
	uint32_t *a3;
	uint32_t *a4;
} TestObjs;

// create test array data
TestObjs *setup(void) {
	TestObjs *objs = malloc(sizeof(TestObjs));

	objs->a1 = (uint32_t *) malloc(sizeof(uint32_t) * 10);
	objs->a1[0] = 1023;
	objs->a1[1] = 5282;
	objs->a1[2] = 8013;
	objs->a1[3] = 18200;
	objs->a1[4] = 26219;
	objs->a1[5] = 46573;
	objs->a1[6] = 61135;
	objs->a1[7] = 77230;
	objs->a1[8] = 89432;
	objs->a1[9] = 95062;

	objs->a2 = (uint32_t *) malloc(sizeof(uint32_t) * 4);
	objs->a2[0] = 2871;
	objs->a2[1] = 41580;
	objs->a2[2] = 59471;
	objs->a2[3] = 75697;

	objs->a3 = (uint32_t *) malloc(sizeof(uint32_t) * 7);
	objs->a3[0] = 557386391;
	objs->a3[1] = 558351265;
	objs->a3[2] = 952667775;
	objs->a3[3] = 1725260461;
	objs->a3[4] = 2638306482;
	objs->a3[5] = 3405964778;
	objs->a3[6] = 3429464822;

	objs->a4 = (uint32_t *) malloc(sizeof(uint32_t) * 9);
	objs->a4[0] = 104597999;
	objs->a4[1] = 109496094;
	objs->a4[2] = 139196332;
	objs->a4[3] = 323168042;
	objs->a4[4] = 353853303;
	objs->a4[5] = 468557795;
	objs->a4[6] = 553369544;
	objs->a4[7] = 620959945;
	objs->a4[8] = 985287269;

	return objs;
}

// delete test array data
void cleanup(TestObjs *objs) {
	free(objs->a4);
	free(objs->a3);
	free(objs->a2);
	free(objs->a1);
	free(objs);
}

void testMerge1(TestObjs *objs);
void testMerge2(TestObjs *objs);

int main(int argc, char **argv) {
	if (argc > 1) {
		tctest_testname_to_execute = argv[1];
	}

	TEST_INIT();

	TEST(testMerge1);
	TEST(testMerge2);

	TEST_FINI();
}

void testMerge1(TestObjs *objs) {
	uint32_t result[14];

	merge(objs->a1, 10, objs->a2, 4, result);

	ASSERT(1023 == result[0]);
	ASSERT(2871 == result[1]);
	ASSERT(5282 == result[2]);
	ASSERT(8013  == result[3]);
	ASSERT(18200 == result[4]);
	ASSERT(26219 == result[5]);
	ASSERT(41580 == result[6]);
	ASSERT(46573 == result[7]);
	ASSERT(59471 == result[8]);
	ASSERT(61135 == result[9]);
	ASSERT(75697 == result[10]);
	ASSERT(77230 == result[11]);
	ASSERT(89432 == result[12]);
	ASSERT(95062 == result[13]);

	uint32_t result2[14];

	merge(objs->a2, 4, objs->a1, 10, result2);

	ASSERT(1023 == result2[0]);
	ASSERT(2871 == result2[1]);
	ASSERT(5282 == result2[2]);
	ASSERT(8013  == result2[3]);
	ASSERT(18200 == result2[4]);
	ASSERT(26219 == result2[5]);
	ASSERT(41580 == result2[6]);
	ASSERT(46573 == result2[7]);
	ASSERT(59471 == result2[8]);
	ASSERT(61135 == result2[9]);
	ASSERT(75697 == result2[10]);
	ASSERT(77230 == result2[11]);
	ASSERT(89432 == result2[12]);
	ASSERT(95062 == result2[13]);
}

void testMerge2(TestObjs *objs) {
	uint32_t result[16];

	merge(objs->a3, 7, objs->a4, 9, result);

	ASSERT(104597999 == result[0]);
	ASSERT(109496094 == result[1]);
	ASSERT(139196332 == result[2]);
	ASSERT(323168042 == result[3]);
	ASSERT(353853303 == result[4]);
	ASSERT(468557795 == result[5]);
	ASSERT(553369544 == result[6]);
	ASSERT(557386391 == result[7]);
	ASSERT(558351265 == result[8]);
	ASSERT(620959945 == result[9]);
	ASSERT(952667775 == result[10]);
	ASSERT(985287269 == result[11]);
	ASSERT(1725260461 == result[12]);
	ASSERT(2638306482 == result[13]);
	ASSERT(3405964778 == result[14]);
	ASSERT(3429464822 == result[15]);

	uint32_t result2[16];

	merge(objs->a4, 9, objs->a3, 7, result2);

	ASSERT(104597999 == result2[0]);
	ASSERT(109496094 == result2[1]);
	ASSERT(139196332 == result2[2]);
	ASSERT(323168042 == result2[3]);
	ASSERT(353853303 == result2[4]);
	ASSERT(468557795 == result2[5]);
	ASSERT(553369544 == result2[6]);
	ASSERT(557386391 == result2[7]);
	ASSERT(558351265 == result2[8]);
	ASSERT(620959945 == result2[9]);
	ASSERT(952667775 == result2[10]);
	ASSERT(985287269 == result2[11]);
	ASSERT(1725260461 == result2[12]);
	ASSERT(2638306482 == result2[13]);
	ASSERT(3405964778 == result2[14]);
	ASSERT(3429464822 == result2[15]);
}
