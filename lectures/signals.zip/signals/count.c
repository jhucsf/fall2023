#include <stdio.h>

#define NCOUNT 100000000
volatile int count = 0;

int main(void) {
	// count up
	for (int i = 0; i < NCOUNT; i++) {
		count++;
	}
	printf("count=%d\n", count);
	return 0;
}
