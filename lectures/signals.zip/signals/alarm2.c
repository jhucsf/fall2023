#include "csapp.h"

#define NCOUNT 100000000
volatile int stop = 0, nsigs = 0, count = 0;

void sigalrm_handler(int signo) {
	if (!stop) {
		nsigs++;
		count++;
	}
}

int main(void) {
	// handle SIGALRM signal
	struct sigaction sa;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sa.sa_handler = sigalrm_handler;
	sigaction(SIGALRM, &sa, NULL);

	// arrange for SIGALRM to be delivered once every millisecond
	struct itimerval itv;
	itv.it_interval.tv_sec = 0;
	itv.it_interval.tv_usec = 1000; // 1000 microseconds = 1 millisecond
	itv.it_value = itv.it_interval;
	setitimer(ITIMER_REAL, &itv, NULL);

	sigset_t mask;
	sigemptyset(&mask);
	sigaddset(&mask, SIGALRM);

	// count up
	for (int i = 0; i < NCOUNT; i++) {
		sigprocmask(SIG_BLOCK, &mask, NULL);
		count++;
		sigprocmask(SIG_UNBLOCK, &mask, NULL);
	}

	// done with count: set stop to 1 to "disable" signal handler
	stop = 1;

	// wait a bit
	sleep(1);

	// See whether count is equal to NCOUNT + nsigs
	printf("count=%d, NCOUNT=%d, nsigs=%d\n", count, NCOUNT, nsigs);
	if (count == NCOUNT + nsigs) {
		printf("  count makes sense\n");
	} else {
		printf("  anomaly detected!\n");
	}

	return 0;
}
