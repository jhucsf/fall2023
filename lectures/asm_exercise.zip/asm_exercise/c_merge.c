#include <assert.h>
#include "merge_sort.h"

void merge(uint32_t *arr, unsigned start, unsigned mid, unsigned end, uint32_t *temp) {
  assert(mid >= start);
  assert(end >= mid);

  unsigned left_index = start, right_index = mid;

  // where to place the next element in the temp array
  unsigned place = start;

  // merge the two sequences into  the temp array
  while (left_index < mid || right_index < end) {
    if (left_index == mid) {
      // left side is empty, use element from right side
      temp[place++] = arr[right_index++];
    } else if (right_index == end) {
      // right side is empty, use element form left side
      temp[place++] = arr[left_index++];
    } else {
      // both sides have at least one element, so use the smaller
      // of the two choices
      uint32_t left_elt = arr[left_index];
      uint32_t right_elt = arr[right_index];

      if (left_elt < right_elt) {
        temp[place++] = left_elt;
        left_index++;
      } else {
        temp[place++] = right_elt;
        right_index++;
      }
    }
  }

  // copy from the temp array back to the main array
  for (unsigned i = start; i < end; i++) {
    arr[i] = temp[i];
  }
}
