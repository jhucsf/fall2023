#ifndef MERGE_SORT_H
#define MERGE_SORT_H

#include <stdint.h>

// Recursive merge sort.
//
// Parameters:
//   arr   - the array to sort
//   start - start index of region of array to sort (inclusive)
//   end   - end index of region of array to sort (exclusive)
//   temp  - a temporary array which is the same size as arr
//           (needed by the merge function)
//
void merge_sort(uint32_t *arr, unsigned start, unsigned end, uint32_t *temp);

// Merge the sorted sequences in the ranges [start, mid) and [mid, end),
// first copying the sorted data to the temp array, and then copying the
// data back to the main array.
//
// Parameters:
//   arr   - the array to sort
//   start - the start index of the first sorted sequence (inclusive)
//   mid   - the end index of the first sorted sequence (exclusive),
//           and the start index of the second sorted sequence (inclusive)
//   end   - the end index of the second sorted sequence (exclusive)
//   temp  - a temporary array the same size as arr; the elements
//           from start (inclusive) to end (exclusive) can be used to
//           store the result of the merge before it is copied back
//           into the main array
//
void merge(uint32_t *arr, unsigned start, unsigned mid, unsigned end, uint32_t *temp);

#endif // MERGE_SORT_H
