/*
 * Very basic webserver
 * Only supports GET requests, only serves files, content types
 * are hard-coded
 *
 * main function
 */

#include <stdio.h>
#include "csapp.h"
#include "webserver.h"

int main(int argc, char **argv) {
	if (argc != 3) {
		fatal("Usage: webserver <port> <webroot>");
	}

	const char *port = argv[1];
	const char *webroot = argv[2];

	int serverfd = open_listenfd((char*) port);
	if (serverfd < 0) {
		fatal("Couldn't open server socket");
	}

	while (1) {
		int clientfd = Accept(serverfd, NULL, NULL);
		if (clientfd < 0) {
			fatal("Error accepting client connection");
		}
		server_chat_with_client(clientfd, webroot);
		close(clientfd);
	}
}
