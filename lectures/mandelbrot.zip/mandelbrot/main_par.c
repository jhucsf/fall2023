#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "mandelbrot.h"

#define NROWS 800
#define NCOLS 800

#define XMIN -2.0
#define XMAX 2.0
#define YMIN -2.0
#define YMAX 2.0

#define NUM_THREADS 4

typedef struct {
	double xmin, xmax, ymin, ymax;
	int *iters;
	int start_row, skip;
} Work;

void *worker(void *arg) {
	Work *work = arg;

	for (int i = work->start_row; i < NROWS; i += work->skip) {
		mandel_compute_row(work->iters, NROWS, NCOLS,
			work->xmin, work->xmax, work->ymin, work->ymax,
			i);
	}

	return NULL;
}

int main(int argc, char **argv) {
	double xmin=XMIN, xmax=XMAX, ymin=YMIN, ymax=YMAX;

	if (argc == 5) {
		xmin = strtod(argv[1], NULL);
		xmax = strtod(argv[2], NULL);
		ymin = strtod(argv[3], NULL);
		ymax = strtod(argv[4], NULL);
	}

	int *iters = malloc(sizeof(int) * NROWS * NCOLS);

	/* master work assignment */
	Work master = { xmin, xmax, ymin, ymax, iters, 0, NUM_THREADS };

	/* start threads */
	pthread_t threads[NUM_THREADS];
	Work work[NUM_THREADS];
	for (int i = 0; i < NUM_THREADS; i++) {
		work[i] = master;
		work[i].start_row = i;
		pthread_create(&threads[i], NULL, worker, &work[i]);
	}

	/* wait for threads to complete */
	for (int i = 0; i < NUM_THREADS; i++) {
		pthread_join(threads[i], NULL);
	}

	mandel_render_img(iters, NROWS, NCOLS, "img.ppm");
	printf("Success?\n");

	return 0;
}
