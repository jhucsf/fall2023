#include <stdio.h>
#include <stdlib.h>
#include "mandelbrot.h"

#define NROWS 800
#define NCOLS 800

#define XMIN -2.0
#define XMAX 2.0
#define YMIN -2.0
#define YMAX 2.0

int main(int argc, char **argv) {
	double xmin=XMIN, xmax=XMAX, ymin=YMIN, ymax=YMAX;

	if (argc == 5) {
		xmin = strtod(argv[1], NULL);
		xmax = strtod(argv[2], NULL);
		ymin = strtod(argv[3], NULL);
		ymax = strtod(argv[4], NULL);
	}

	int *iters = malloc(sizeof(int) * NROWS * NCOLS);
	for (int i = 0; i < NROWS; i++) {
		mandel_compute_row(iters, NROWS, NCOLS,
			xmin, xmax, ymin, ymax,
			i);
	}
	mandel_render_img(iters, NROWS, NCOLS, "img.ppm");
	printf("Success?\n");
	return 0;
}
