#include <stdio.h>
#include <math.h>
#include "mandelbrot.h"

#define max(a,b) ((a)>(b)?(a):(b))

int mandel_num_iters(Complex c) {
	Complex z = { 0.0, 0.0 };
	int num_iters = 0;
	while (complex_mag(z) < 2.0 && num_iters < MAX_ITERS) {
		z = complex_add(complex_mul(z, z), c);
		num_iters++;
	}
	return num_iters;
}

void mandel_compute_row(int *iters, int nrows, int ncols,
	double xmin, double xmax, double ymin, double ymax,
	int row_num) {

	double dy = (ymax-ymin) / nrows;
	double dx = (xmax-xmin) / ncols;

	for (int j = 0; j < ncols; j++) {
		Complex c = {
			xmin + j*dx,
			ymin + row_num*dy
		};
		int idx = row_num*ncols + j;
		iters[idx] = mandel_num_iters(c);
	}
}

void mandel_render_img(const int *iters, int nrows, int ncols, const char *fname) {
	FILE *out = fopen(fname, "wb");
	fprintf(out, "P6\n%d %d\n255\n", ncols, nrows);
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			int count = iters[i*ncols + j];
			if (count == MAX_ITERS) {
				/* assume C was in the set */
				unsigned char pix[3] = {0,0,0};
				fwrite(pix, 1, 3, out);
			} else {
				/* C is not in the set, choose a color
				 * based on the iteration count */
				double f = (count/(double)MAX_ITERS);
				double x = max(log10(f*10000.0)/4.0, 0.0);
				int i = (int)(x*256.0);
				unsigned char pix[3] = {0,(unsigned char)i,255-(unsigned char)i};
				fwrite(pix, 1, 3, out);
			}
		}
	}
	fclose(out);
}
