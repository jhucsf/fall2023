#ifndef MANDELBROT_H
#define MANDELBROT_H

#include <math.h>

typedef struct {
	double real, imag;
} Complex;

static inline Complex complex_add(Complex left, Complex right) {
	Complex sum = { left.real+right.real, left.imag+right.imag };
	return sum;
}

static inline Complex complex_mul(Complex left, Complex right) {
	double a = left.real, b = left.imag, c = right.real, d = right.imag;
	Complex prod = { a*c - b*d, b*c + a*d };
	return prod;
}

static inline double complex_mag(Complex c) {
	return sqrt(c.real*c.real + c.imag*c.imag);
}

#define MAX_ITERS 5000

int mandel_num_iters(Complex c);
void mandel_compute_row(int *iters, int nrows, int ncols,
	double xmin, double xmax, double ymin, double ymax,
	int row_num);
void mandel_render_img(const int *iters, int nrows, int ncols, const char *fname);

#endif /* MANDELBROT_H */
