#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

const int NUM_INCR=100000000, NTHREADS=2;
typedef struct {
  volatile int count;
  pthread_mutex_t lock, lock2;
} Shared;

void *worker1(void *arg) {
	Shared *obj = arg;
	for (int i = 0; i < NUM_INCR/NTHREADS; i++) {
		pthread_mutex_lock(&obj->lock);
		pthread_mutex_lock(&obj->lock2);
		obj->count++;
		pthread_mutex_unlock(&obj->lock2);
		pthread_mutex_unlock(&obj->lock);
	}
	return NULL;
}

void *worker2(void *arg) {
	Shared *obj = arg;
	for (int i = 0; i < NUM_INCR/NTHREADS; i++) {
		pthread_mutex_lock(&obj->lock2);
		pthread_mutex_lock(&obj->lock);
		obj->count++;
		pthread_mutex_unlock(&obj->lock);
		pthread_mutex_unlock(&obj->lock2);
	}
	return NULL;
}

int main(void) {
	Shared *obj = calloc(1, sizeof(Shared));
	pthread_mutex_init(&obj->lock, NULL);
	pthread_mutex_init(&obj->lock2, NULL);
	pthread_t threads[NTHREADS];
	pthread_create(&threads[0], NULL, worker1, obj);
	pthread_create(&threads[1], NULL, worker2, obj);
	for (int i = 0; i < NTHREADS; i++)
		pthread_join(threads[i], NULL);
	printf("%d\n", obj->count);
	pthread_mutex_destroy(&obj->lock);
	return 0;
}
