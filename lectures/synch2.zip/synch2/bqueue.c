#include <stdlib.h>
#include "bqueue.h"

BoundedQueue *bqueue_create(unsigned max_items) {
	BoundedQueue *bq = malloc(sizeof(BoundedQueue));
	bq->data = malloc(max_items * sizeof(void *));
	bq->max_items = max_items;
	bq->count = bq->head = bq->tail = 0;
	pthread_mutex_init(&bq->lock, NULL);
	pthread_cond_init(&bq->not_full, NULL);
	pthread_cond_init(&bq->not_empty, NULL);
	return bq;
}

void bqueue_destroy(BoundedQueue *bq) {
	pthread_mutex_destroy(&bq->lock);
	pthread_cond_destroy(&bq->not_empty);
	pthread_cond_destroy(&bq->not_full);
	free(bq->data);
	free(bq);
}

void bqueue_enqueue(BoundedQueue *bq, void *item) {
	pthread_mutex_lock(&bq->lock);

	while (bq->count >= bq->max_items) {
		pthread_cond_wait(&bq->not_full, &bq->lock);
	}

	bq->data[bq->head] = item;
	bq->head = (bq->head + 1) % bq->max_items;
	bq->count++;

	pthread_cond_broadcast(&bq->not_empty);

	pthread_mutex_unlock(&bq->lock);
}

void *bqueue_dequeue(BoundedQueue *bq) {
	pthread_mutex_lock(&bq->lock);

	while (bq->count <= 0) {
		pthread_cond_wait(&bq->not_empty, &bq->lock);
	}

	void *item = bq->data[bq->tail];
	bq->tail = (bq->tail + 1) % bq->max_items;
	bq->count--;

	pthread_cond_broadcast(&bq->not_full);

	pthread_mutex_unlock(&bq->lock);

	return item;
}
