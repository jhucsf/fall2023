These are example programs for Lecture 7.
