The coroutine library is available from: https://github.com/hnes/libaco

Run make to compile the two example echo servers.

Run servers as

  ./echoserv 30000

  ./echoserv_co 30000

You can specify a different port if port 30000 is not available.

You can use telnet as a client, e.g.:

  telnet localhost 30000

You should be able to start multiple clients in different terminals,
and freely interleave messages among the clients.
