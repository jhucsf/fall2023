// Example echo server using I/O multiplexing

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include "csapp.h"

#define MAX_FD 1024
#define BUFFER_SIZE 1024

// Client states
#define CONN_READING  0  // server is receiving a message from client
#define CONN_WRITING  1  // server is sending a message to client
#define CONN_DONE     2  // connection is done

// Data structure keeping track of the state of a client connection
struct Connection {
  char in_buf[BUFFER_SIZE];
  char out_buf[BUFFER_SIZE];
  int in_count, out_pos, out_count;
  int state;
};

void fatal(const char *msg) {
  fprintf(stderr, "%s\n", msg);
  exit(1);
}

void *xmalloc(size_t n) {
  void *buf = malloc(n);
  if (!buf) {
    fatal("malloc failed");
  }
  return buf;
}

void make_nonblocking(int fd) {
  int flags = fcntl(fd, F_GETFL, 0);
  if (flags < 0) {
    fatal("fcntl failed: could not get flags");
  }
  flags |= O_NONBLOCK;
  if (fcntl(fd, F_SETFL, flags) < 0) {
    fatal("fcntl failed: could not set flags");
  }
}

struct Connection *create_client_conn(void) {
  struct Connection *conn = xmalloc(sizeof(struct Connection));
  conn->in_count = 0;
  conn->out_pos = 0;
  conn->out_count = 0;
  conn->state = CONN_READING;
  return conn;
}

void client_do_read(int fd, struct Connection *conn) {
  // once a message has been read, ignore further input from client
  if (conn->state != CONN_READING) {
    return;
  }

  // How much space remains in the read buffer?
  // Note that we leave 1 byte available so that out_buf
  // is guaranteed to have enough space for the entire
  // message, plus the \r\n terminator sequence.
  int remaining = BUFFER_SIZE - conn->in_count - 1;

  // Try to read more data
  ssize_t rc = read(fd, conn->in_buf + conn->in_count, remaining);
  if (rc < 0) {
    fatal("read failed");
  }
  conn->in_count += rc;

  // See if a complete message was received
  char *nl = memchr(conn->in_buf, '\n', (size_t) conn->in_count);

  if (!nl && conn->in_count >= BUFFER_SIZE) {
    // Received maximum amount of data without seeing a
    // newline, close connection
    conn->state = CONN_DONE;
    return;
  }

  if (!nl) {
    // Newline not received yet
    return;
  }

  // The client has sent a complete message,
  // we can now switch to sending response

  // find the end of the message, not including the terminating
  // \n or \r\n
  char *end = nl;
  if (end > conn->in_buf && *(end - 1) == '\r') {
    end--;
  }
  int msg_len = (int) (end - conn->in_buf);

  // if the message was "quit", then close the connection
  if (msg_len == 4 && memcmp(conn->in_buf, "quit", 4) == 0) {
    conn->state = CONN_DONE;
  } else {
    // transfer message to out_buf
    memcpy(conn->out_buf, conn->in_buf, (size_t) msg_len);
    memcpy(conn->out_buf + msg_len, "\r\n", 2);
    conn->out_pos = 0;
    conn->out_count = msg_len + 2;

    // move data remaining in in_buf to the beginning of in_buf,
    // so it can become part of the next received message
    int remaining = conn->in_count - (nl - conn->in_buf) - 1;
    memmove(conn->in_buf, conn->in_buf + msg_len + 1, remaining);
    conn->in_count = remaining;

    // send message
    conn->state = CONN_WRITING;
  }
}

void client_do_write(int fd, struct Connection *conn) {
  if (conn->state != CONN_WRITING) {
    return;
  }

  // Try to send data back to the client
  int remaining = conn->out_count - conn->out_pos;
  ssize_t rc = write(fd, conn->out_buf + conn->out_pos, (size_t) remaining);
  if (rc < 0) {
    fatal("write failed");
  }

  conn->out_pos += rc;
  if (conn->out_pos == conn->out_count) {
    // Sent entire response!
    // Switch back to CONN_READING
    conn->state = CONN_READING;
  }
}

int main(int argc, char *argv[]) {
  if (argc != 2) {
    fprintf(stderr, "Usage: ./echoserv <port>\n");
    return 1;
  }

  struct Connection *client_conn[MAX_FD] = { 0 };

  // Create server socket
  int serverfd = open_listenfd(argv[1]);
  if (serverfd < 0) {
    fatal("Could not open server socket");
  }

  int maxfd = serverfd;

  for (;;) {
    fd_set readfds, writefds;
    FD_ZERO(&readfds);
    FD_ZERO(&writefds);

    // Determine which file descriptors should be in the read and write sets.
    // It's counterproductive to put a connection file descriptor in the write
    // set if it currently wants to read.
    for (int fd = 0; fd <= maxfd; fd++) {
      struct Connection *conn = client_conn[fd];
      if (conn) {
        if (conn->state == CONN_READING) {
          FD_SET(fd, &readfds);
        } else if (conn->state == CONN_WRITING) {
          FD_SET(fd, &writefds);
        }
      }
    }

    // Server socket is always in readfds
    FD_SET(serverfd, &readfds);

    // Wait for a file descriptor to become ready
    int rc = select(maxfd + 1, &readfds, &writefds, NULL, NULL);
    if (rc < 0) {
      fatal("select failed");
    }

    // If server socket became ready for reading, that means that
    // a request for a new connection has arrived
    if (FD_ISSET(serverfd, &readfds)) {
      int clientfd = Accept(serverfd, NULL, NULL);

      // make clientfd nonblocking
      make_nonblocking(clientfd);

      // update maxfd if necessary
      if (clientfd > maxfd) {
        maxfd = clientfd;
      }

      // create Connection object for connection
      client_conn[clientfd] = create_client_conn();
    }

    // Check for file descriptors that became ready to read and write
    for (int fd = 0; fd <= maxfd; fd++) {
      if (client_conn[fd] != NULL) {
        struct Connection *conn = client_conn[fd];
        if (FD_ISSET(fd, &readfds)) {
          client_do_read(fd, conn);
        }
        if (FD_ISSET(fd, &writefds)) {
          client_do_write(fd, conn);
        }
        if (conn->state == CONN_DONE) {
          // close connection
          close(fd);
          // deallocate Connection
          free(conn);
          client_conn[fd] = NULL;
        }
      }
    }
  }
}
