// Example echo server using I/O multiplexing and coroutines

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "csapp.h"
#include "aco.h"       // coroutine library: https://github.com/hnes/libaco

#define MAX_FD 1024
#define BUFFER_SIZE 1024

// Connections indicate to the main loop what kind of I/O they
// are interested in performing, so their coroutines can be
// scheduled appropriately.
#define CONN_READING 0
#define CONN_WRITING 1

struct Connection {
  aco_t *coroutine;
  int state;
  int fd;
  char in_buf[BUFFER_SIZE];
  char out_buf[BUFFER_SIZE];
  int in_count;
  int out_count;
};

void fatal(const char *msg) {
  fprintf(stderr, "%s\n", msg);
  exit(1);
}

void *xmalloc(size_t n) {
  void *buf = malloc(n);
  if (!buf) {
    fatal("malloc failed");
  }
  return buf;
}

void make_nonblocking(int fd) {
  int flags = fcntl(fd, F_GETFL, 0);
  if (flags < 0) {
    fatal("fcntl failed: could not get flags");
  }
  flags |= O_NONBLOCK;
  if (fcntl(fd, F_SETFL, flags) < 0) {
    fatal("fcntl failed: could not set flags");
  }
}

struct Connection *create_client_conn(int fd) {
  struct Connection *conn = xmalloc(sizeof(struct Connection));
  conn->state = CONN_READING;
  conn->fd = fd;
  conn->in_count = 0;
  conn->out_count = 0;
  return conn;
}

ssize_t co_read(int fd, void *buf, size_t n) {
  for (;;) {
    ssize_t rc = read(fd, buf, n);
    if (rc < 0 && errno == EWOULDBLOCK) {
      // Read would have blocked, so yield control
      // back to main routine
      aco_yield();
    } else if (rc < 0) {
      fatal("read failed");
    } else {
      return rc;
    }
  }
}

ssize_t co_write_fully(int fd, const void *buf, size_t n) {
  int remaining = (int) n;
  while (remaining > 0) {
    ssize_t rc = write(fd, buf, n);
    if (rc < 0 && errno == EWOULDBLOCK) {
      // Write would have blocked, so yield control
      // back to main routine
      aco_yield();
    } else if (rc < 0) {
      fatal("write failed");
    } else {
      remaining -= rc;
    }
  }
  return (ssize_t) n;
}

// This is similar to rio_readlineb from the csapp module,
// but yields back to the main routine if a read would block.
// Note that the yield is in co_read().
void co_readline(struct Connection *conn) {
  for (;;) {
    int remaining = BUFFER_SIZE - conn->in_count - 1;
    ssize_t rc = co_read(conn->fd, conn->in_buf + conn->in_count, remaining);
    conn->in_count += rc;
    char *nl = memchr(conn->in_buf, '\n', (size_t) conn->in_count);
    if (nl) {
      // read a newline, so a complete line has been received

      // copy message to out_buf
      char *end = nl;
      if (end > conn->in_buf && *(end - 1) == '\r') {
        end--;
      }
      conn->out_count = end - conn->in_buf;
      memcpy(conn->out_buf, conn->in_buf, conn->out_count);
      conn->out_buf[conn->out_count] = '\0';

      // copy any remaining input data to the beginning of in_buf
      int remaining = (conn->in_buf + conn->in_count) - (nl + 1);
      memmove(conn->in_buf, nl + 1, remaining);
      conn->in_count = remaining;
      return;
    }
    if (conn->in_count >= BUFFER_SIZE - 1) {
      // buffer is full, but there was no newline
      conn->in_buf[BUFFER_SIZE - 1] = '\0';
      return;
    }
  }
}

void chat_with_client(void) {
  struct Connection *conn = (struct Connection *) aco_get_arg();
  for (;;) {
    // read a line
    conn->state = CONN_READING;
    co_readline(conn);

    // if line was "quit", we're done
    if (strcmp(conn->out_buf, "quit") == 0) {
      break;
    }

    // echo line back to client
    conn->state = CONN_WRITING;
    co_write_fully(conn->fd, conn->out_buf, strlen(conn->out_buf));
    co_write_fully(conn->fd, "\r\n", 2);
  }
  aco_exit();
}

int main(int argc, char *argv[]) {
  if (argc != 2) {
    fprintf(stderr, "Usage: ./echoserv_co <port>\n");
    return 1;
  }

  aco_thread_init(NULL);
  aco_t* main_co = aco_create(NULL, NULL, 0, NULL, NULL);
  aco_share_stack_t* sstk = aco_share_stack_new(0);

  struct Connection *client_conn[MAX_FD] = { 0 };

  // Create server socket
  int serverfd = open_listenfd(argv[1]);
  if (serverfd < 0) {
    fatal("Could not open server socket");
  }

  // Maintain a set of active file descriptors and
  // add server socket fd to it
  int maxfd = serverfd;

  for (;;) {
    fd_set readfds, writefds;
    FD_ZERO(&readfds);
    FD_ZERO(&writefds);

    // Determine which file descriptors should be in the read and write sets.
    // It's counterproductive to put a connection file descriptor in the write
    // set if it currently wants to read.
    for (int fd = 0; fd <= maxfd; fd++) {
      struct Connection *conn = client_conn[fd];
      if (conn) {
        if (conn->state == CONN_READING) {
          FD_SET(fd, &readfds);
        } else if (conn->state == CONN_WRITING) {
          FD_SET(fd, &writefds);
        }
      }
    }

    // Server socket is always in readfds
    FD_SET(serverfd, &readfds);

    int rc = select(maxfd + 1, &readfds, &writefds, NULL, NULL);
    if (rc < 0) {
      fatal("select failed");
    }

    // If server socket became ready for reading, that means that
    // a request for a new connection has arrived
    if (FD_ISSET(serverfd, &readfds)) {
      int clientfd = Accept(serverfd, NULL, NULL);

      // make clientfd nonblocking
      make_nonblocking(clientfd);

      // See if maxfd increases
      if (clientfd > maxfd) {
        maxfd = clientfd;
      }

      // create Connection object for connection
      struct Connection *conn = create_client_conn(clientfd);
      aco_t *co = aco_create(main_co, sstk, 0, chat_with_client, conn);
      conn->coroutine = co;
      client_conn[clientfd] = conn;
    }

    for (int fd = 0; fd <= maxfd; fd++) {
      struct Connection *conn = client_conn[fd];

      if (conn != NULL && (FD_ISSET(fd, &readfds) || FD_ISSET(fd, &writefds))) {
        // Allow the client coroutine to do some work.
        // It will yield when it attempts a blocking operation,
        // or exit if the connection has finished.
        aco_t *co = conn->coroutine;
        aco_resume(co);
        if (co->is_end) {
          // connection has finished
          aco_destroy(co);
          close(conn->fd);
          free(conn);
          client_conn[fd] = NULL;
        }
      }
    }
  }
}
