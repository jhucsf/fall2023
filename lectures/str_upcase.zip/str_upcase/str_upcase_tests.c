#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tctest.h"

typedef struct {
  char str1[200];
  char str2[200];
  char str3[200];
  char str4[200];
  char str5[200];
} TestObjs;

TestObjs *setup(void);
void cleanup(TestObjs *objs);

void test_str1(TestObjs *objs);
void test_str2(TestObjs *objs);
void test_str3(TestObjs *objs);
void test_str4(TestObjs *objs);
void test_str5(TestObjs *objs);

// This is the assembly language function being tested
void str_upcase(char *s);

int main(int argc, char **argv) {
  if (argc >= 2) {
    tctest_testname_to_execute = argv[1];
  }

  TEST_INIT();

  TEST(test_str1);
  TEST(test_str2);
  TEST(test_str3);
  TEST(test_str4);
  TEST(test_str5);

  TEST_FINI();
}

TestObjs *setup(void) {
  TestObjs *objs = malloc(sizeof(TestObjs));

  strcpy(objs->str1, "the quick brown fox jumped over the lazy dog");
  strcpy(objs->str2, "A Strong Smell of Turpentine Prevails Throughout");
  strcpy(objs->str3, "NOTHING TO SEE HERE");
  strcpy(objs->str4, "=TH#wo#nv%uD=aon$H7BCk@N#JP)M(C!Ttp=jZcz");
  strcpy(objs->str5, "");

  return objs;
}

void cleanup(TestObjs *objs) {
  free(objs);
}

void test_str1(TestObjs *objs) {
  str_upcase(objs->str1);
  ASSERT(0 == strcmp(objs->str1, "THE QUICK BROWN FOX JUMPED OVER THE LAZY DOG"));
}

void test_str2(TestObjs *objs) {
  str_upcase(objs->str2);
  ASSERT(0 == strcmp(objs->str2, "A STRONG SMELL OF TURPENTINE PREVAILS THROUGHOUT"));
}

void test_str3(TestObjs *objs) {
  str_upcase(objs->str3);
  ASSERT(0 == strcmp(objs->str3, "NOTHING TO SEE HERE"));
}

void test_str4(TestObjs *objs) {
  str_upcase(objs->str4);
  ASSERT(0 == strcmp(objs->str4, "=TH#WO#NV%UD=AON$H7BCK@N#JP)M(C!TTP=JZCZ"));
}

void test_str5(TestObjs *objs) {
  str_upcase(objs->str5);
  ASSERT(0 == strcmp(objs->str5, ""));
}
